//======================================================================
//
//	ball, 16x16@4, 
//	+ palette 128 entries, not compressed
//	+ 4 tiles not compressed
//	Total size: 256 + 128 = 384
//
//	Time-stamp: 2006-04-09, 19:33:17
//	Exported by Cearn's Usenti v1.7.4
//	(comments, kudos, flames to "daytshen@hotmail.com")
//
//======================================================================

#ifndef __BALL__
#define __BALL__

#define ballPalLen 256
extern const unsigned int ballPal[64];

#define ballTilesLen 128
extern const unsigned int ballTiles[32];

#endif // __BALL__

