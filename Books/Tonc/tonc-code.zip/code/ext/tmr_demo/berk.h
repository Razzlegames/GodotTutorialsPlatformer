
//{{BLOCK(berk)

#ifndef __BERK__
#define __BERK__

// Berka! Berka! Berka!
// berk.gif font from headsipn's collection.
// 24x40@4, tiled, with palette

extern const TFont berkFont;

#define berkGlyphsLen 5280
extern const unsigned int berkGlyphs[1320];

#define berkPalLen 32
extern const unsigned short berkPal[32];

#endif // __BERK__

//}}BLOCK(berk)
