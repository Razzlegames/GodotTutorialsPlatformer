
//{{BLOCK(tahoma9)

#ifndef __TAHOMA9__
#define __TAHOMA9__

extern const TFont tahoma9Font;

#define tahoma9GlyphsLen 3584
extern const unsigned int tahoma9Glyphs[896];

#define tahoma9WidthsLen 224
extern const unsigned char tahoma9Widths[224];

#endif // __TAHOMA9__

//}}BLOCK(tahoma9)
