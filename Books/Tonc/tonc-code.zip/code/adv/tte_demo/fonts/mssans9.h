
//{{BLOCK(mssans9)

#ifndef __MSSANS9__
#define __MSSANS9__

// MicroSoft Sans Serif 9, 32-255, 1bpp

extern const TFont mssans9Font;

#define mssans9GlyphsLen 3584
extern const unsigned int mssans9Glyphs[896];

#define mssans9WidthsLen 224
extern const unsigned char mssans9Widths[224];

#endif // __MSSANS9__

//}}BLOCK(mssans9)
