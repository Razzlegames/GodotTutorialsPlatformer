
//{{BLOCK(cyber16)

#ifndef __CYBER16__
#define __CYBER16__

// Cybernator font, 8x16@4. Missing ascii have been added.

extern const TFont cyber16Font;

#define cyber16GlyphsLen 6144
extern const unsigned int cyber16Glyphs[1536];

#define cyber16PalLen 32
extern const unsigned short cyber16Pal[32];

#endif // __CYBER16__

//}}BLOCK(cyber16)
