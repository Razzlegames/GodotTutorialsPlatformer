//
// Font master header.
//

#ifndef __FONTS_H__
#define __FONTS_H__

#include "cyber16.h"
#include "mssans9.h"
#include "tahoma9.h"
#include "verdana11.h"
#include "yesh1.h"

#endif	// __FONTS_H__

// EOF
